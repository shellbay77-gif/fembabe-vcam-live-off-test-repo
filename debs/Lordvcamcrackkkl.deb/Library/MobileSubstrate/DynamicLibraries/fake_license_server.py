#!/usr/bin/env python3
"""
LordVCAM Fake License Server (HTTP-Version — kein TLS!)
Emuliert http://127.0.0.1:443/v1/auth/* und /v1/plans
mit HMAC-SHA256 (Key K). Loggt alles nach requests.log
"""
import hashlib, hmac, json, base64, time, uuid, os
from http.server import BaseHTTPRequestHandler, HTTPServer

K_HEX = "3ffc95cfe8819ece270065ba49416707626292f1406907760c93960cdc6b917b"
# VERIFIZIERT: Der Client nutzt den Key als 64-Zeichen-Hex-STRING (C-String, strlen),
# NICHT als 32-Byte-Binary (3f214.c: _strlen(pcVar9) vor _CCHmac).
K = K_HEX.encode()  # 64 ASCII chars

LOG_PATH = "requests.log"

def log_full(msg):
    with open(LOG_PATH, "a") as f:
        f.write(msg + "\n")
    try:
        print(msg, flush=True)
    except Exception:
        pass

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _read_body(self):
        ln = int(self.headers.get('Content-Length', 0))
        return self.rfile.read(ln) if ln else b''

    def _send_json(self, obj, request_nonce=''):
        body = json.dumps(obj, separators=(',', ':')).encode()
        mac = hmac.new(K, body + request_nonce.encode(), hashlib.sha256).digest()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('x-vc-response-sig', base64.b64encode(mac).decode())
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        log_full(f"[SENT] body={body.decode()} nonce={request_nonce!r}")

    def _handle(self):
        body = self._read_body()
        request_nonce = self.headers.get('X-VC-Nonce', '')
        log_full(f"\n===== {self.command} {self.path} =====")
        for k, v in self.headers.items():
            log_full(f"  {k}: {v}")
        log_full(f"[BODY] {body.decode(errors='replace') if body else '(leer)'}")
        log_full(f"[NONCE] {request_nonce!r}")
        return body, request_nonce

    def do_POST(self):
        body, request_nonce = self._handle()
        path = self.path
        # disk_text_hash aus dem Request echoen -> der Tweak baut daraus die
        # Attestation (SHA256(uVar7+"_0x7A_"+integrity_hash+"_VC_PROOF_7f3a2b9e"))
        # und der 60s-LICENSE_SYNC besteht. Der Client sendet den Hash seiner
        # EIGENEN geladenen Dylib -> Self-Integrity passt automatisch.
        try:
            req_json = json.loads(body.decode()) if body else {}
        except Exception:
            req_json = {}
        disk_hash = req_json.get('disk_text_hash', '')

        if path == '/v1/auth/login':
            resp = {
                "status": "valid",
                "token": "faketoken_" + uuid.uuid4().hex,
                "auth_token": "fakeauth_" + uuid.uuid4().hex,
                "expires_at": int(time.time()) + 10*365*24*3600,
                "user_mode": "member",
                "user_balance": "999.99",
                "min_plan_price": "1.99",
                "message": "ok"
            }
            if disk_hash:
                resp["integrity_hash"] = disk_hash
            self._send_json(resp, request_nonce)
        elif path == '/v1/auth/validate':
            resp = {
                "status": "valid",
                "expires_at": int(time.time()) + 10*365*24*3600,
                "user_mode": "member",
                "user_balance": "999.99",
                "min_plan_price": "1.99",
                "latest_version": "2.0.995",
                "message": "ok"
            }
            if disk_hash:
                resp["integrity_hash"] = disk_hash
            self._send_json(resp, request_nonce)
        elif path == '/v1/auth/register':
            resp = {"status": "valid", "token": "faketoken_" + uuid.uuid4().hex, "message": "ok"}
            self._send_json(resp, request_nonce)
        elif path == '/v1/auth/logout':
            resp = {"status": "valid", "message": "ok"}
            self._send_json(resp, request_nonce)
        elif path == '/v1/auth/set-currency':
            resp = {"status": "ok", "message": "ok"}
            self._send_json(resp, request_nonce)
        else:
            resp = {"status": "error", "message": "unknown endpoint"}
            self._send_json(resp, request_nonce)

    def do_GET(self):
        body, request_nonce = self._handle()
        if self.path == '/v1/plans':
            plans = {
                "plans": [
                    {"id": 1, "name": "1 Hour", "price": "9.90", "price_usd": "1.99",
                     "duration_value": 1, "duration_unit": "hours", "popular": False, "lifetime": False},
                    {"id": 2, "name": "1 Day", "price": "19.90", "price_usd": "3.99",
                     "duration_value": 1, "duration_unit": "days", "popular": True, "lifetime": False},
                    {"id": 3, "name": "1 Week", "price": "99.90", "price_usd": "19.99",
                     "duration_value": 1, "duration_unit": "weeks", "popular": False, "lifetime": False},
                    {"id": 4, "name": "1 Month", "price": "299.90", "price_usd": "59.99",
                     "duration_value": 1, "duration_unit": "months", "popular": False, "lifetime": False},
                ],
                "minimum_deposit": 10
            }
            self._send_json(plans, request_nonce)
        else:
            self._send_json({"status": "error", "message": "not found"}, request_nonce)

    def log_message(self, fmt, *args):
        log_full("[HTTP] " + fmt % args)

def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    httpd = HTTPServer(('127.0.0.1', 443), Handler)
    log_full("LordVCAM Fake License Server (HTTP) auf http://127.0.0.1:443")
    log_full("Key K = " + K_HEX)
    httpd.serve_forever()

if __name__ == '__main__':
    main()
