"""Scoped, reversible Choicy configuration; no hooks or crash suppression."""
import argparse
import os
import pathlib
import plistlib
import tempfile

def load(path):
    if not path.exists(): return {}
    with path.open('rb') as f: return plistlib.load(f)

def save(path, data, owner=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.fileproviderfix-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            plistlib.dump(data, f)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(name, 0o644)
        if owner is not None and hasattr(os, 'chown'): os.chown(name, *owner)
        os.replace(name, path)
    finally:
        if os.path.exists(name): os.unlink(name)

def configure(action, prefs, state):
    settings = load(prefs)
    daemons = settings.setdefault('daemonSettings', {})
    entry = daemons.setdefault('fileproviderd', {})
    key = 'tweakInjectionDisabled'
    if action == 'install':
        if not state.exists():
            original = {'present': key in entry, 'value': entry.get(key, False)}
            save(state, original)
        entry[key] = True
    else:
        if not state.exists(): return
        original = load(state)
        # Do not undo a user's subsequent change to this setting.
        if entry.get(key) is True:
            if original['present']: entry[key] = original['value']
            else: entry.pop(key, None)
        if not entry: daemons.pop('fileproviderd', None)
        if not daemons: settings.pop('daemonSettings', None)
    owner = (prefs.stat().st_uid, prefs.stat().st_gid) if prefs.exists() else (501, 501)
    save(prefs, settings, owner)
    if action == 'remove': state.unlink()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['install', 'remove'])
    parser.add_argument('root')
    args = parser.parse_args()
    root = pathlib.Path(args.root)
    configure(args.action, root/'var/mobile/Library/Preferences/com.opa334.choicyprefs.plist',
              root/'var/lib/fembabe-fileprovider-fix/original.plist')
